module Sys
  class ProcTable
    # The version of the sys-proctable library
    VERSION = '1.2.5'.freeze
  end
end
